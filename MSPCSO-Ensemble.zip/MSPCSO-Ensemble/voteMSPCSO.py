import sys

import hpelm
import numpy as np
import torch
from sklearn.ensemble import RandomForestClassifier, ExtraTreesClassifier
from sklearn.feature_selection import mutual_info_classif
from sklearn.metrics import accuracy_score, f1_score, recall_score
from sklearn.model_selection import cross_val_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from torch import optim, nn
# import  visdom
import torchvision
from torch.utils.data import DataLoader
import pandas as pd
from pokemon0 import Pokemon
# from    resnet import ResNet18
from torchvision.models import resnet18
import os
from utils import Flatten
from mealpy import FloatVar, MPA
import pickle
from torchvision import transforms, models
from    PIL import Image
def evalute(model, loader):
    model.eval()

    correct = 0
    total = len(loader.dataset)
    total_val =0
    for x, y in loader:
        x, y = x.to(device), y.to(device)
        with torch.no_grad():
            logits = model(x)
            pred = logits.argmax(dim=1)
        total_val += y.size(0)
        correct += torch.eq(pred, y).sum().float().item()
# y.size(0)
    return correct / total

def get_evaluate_acc_pred(model, loader):
    model.eval()

    correct = 0
    total = len(loader.dataset)
    total_val = 0
    predictions = []  # 存储所有的预测结果

    for x, y in loader:
        x, y = x.to(device), y.to(device)
        with torch.no_grad():
            logits = model(x)
            pred = logits
            predictions.extend(pred.cpu().numpy())  # 将预测值转换为 numpy 数组并添加到列表中
         
    return predictions
def get_evaluate_acc_pred0(model, loader):
    global device
    model.eval()

    correct = 0
    total = 0  # 用于计算实际样本总数
    predictions = []  # 存储所有的预测结果

    for x, y in loader:
        x, y = x.to(device), y.to(device)
        with torch.no_grad():
            logits = model(x)
            # print(logits.shape)
            pred = logits.argmax(dim=1)  # 预测类别
            predictions.extend(pred.cpu().numpy())  # 存储预测结果

        # 累计样本数
        total += y.size(0)
        # 统计正确预测的数量
        correct += (pred == y).sum().item()

    # 确保 total 不为 0
    if total == 0:
        raise ValueError("数据加载器没有提供任何样本，请检查数据加载器的配置。")

    accuracy = correct / total
    return accuracy, predictions


def getevaluteY(model, loader):
    pre_Y = []
    Y = []
    model.eval()

    correct = 0
    total = len(loader.dataset)
    
    for x, y in loader:
        x, y = x.to(device), y.to(device)
        with torch.no_grad():
            logits = model(x)
            pred = logits.argmax(dim=1)
            # 将预测的Y和实际的Y追加到列表中
            pre_Y.extend(pred.cpu().numpy())
            Y.extend(y.cpu().numpy())
        correct += torch.eq(pred, y).sum().float().item()

    return pre_Y, Y

import random

    
class Mobilenet_v2(nn.Module):
    def __init__(self):
        super().__init__()
        self.base = torchvision.models.mobilenet_v2(pretrained=True)
        
        for param in list(self.base.parameters())[:-15]:
            param.requires_grad = False
            
        self.block = nn.Sequential(
            nn.Linear(1280, 128),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(128, 4),
        )
        self.base.classifier = nn.Sequential()
        self.base.fc = nn.Sequential()
        
        
    def get_optimizer(self):
        return torch.optim.AdamW([
            {'params' : self.base.parameters(), 'lr': 3e-5},
            {'params' : self.block.parameters(), 'lr': 8e-4}
        ])
        
        
    def forward(self, x):
        x = self.base(x)
        x = self.block(x)
        return x   

import torch
import torchvision.models as models
import torch.nn as nn

class ConvNeXtModel(nn.Module):
    def __init__(self, num_classes=4):
        super().__init__()
        # 加载预训练的 ConvNeXt 模型
        self.base = models.convnext_base(pretrained=True)  # 可选其他版本，如 convnext_small, convnext_large
        
        # 冻结大部分层
        for param in list(self.base.parameters())[:-15]:
            param.requires_grad = False
            
        # 替换 classifier 层，实现自定义分类头
        self.base.classifier[2] = nn.Sequential(
            nn.Flatten(),  # 扁平化
            nn.Linear(self.base.classifier[2].in_features, 128),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(128, num_classes)
        )
        
    def get_optimizer(self):
        return torch.optim.AdamW([
            {'params': self.base.parameters(), 'lr': 3e-5},
            {'params': self.base.classifier[2].parameters(), 'lr': 8e-4}
        ])
    
    def forward(self, x):
        x = self.base(x)
        return x
import torch
import torch.nn as nn
import torchvision.models as models

class SwinTransformerModel(nn.Module):
    def __init__(self, num_classes=4):
        super(SwinTransformerModel, self).__init__()
        # 加载预训练的 Swin Transformer 模型
        self.base = models.swin_t(weights='IMAGENET1K_V1')  # 选择 Swin-Tiny 模型
        
        # 冻结部分层参数（例如，冻结前面的层）
        for param in list(self.base.parameters())[:-15]:  # 根据需求冻结特定层
            param.requires_grad = False

        # 自定义分类层
        self.base.head = nn.Sequential(
            nn.Flatten(),  # 将输出平坦化
            nn.Linear(self.base.head.in_features, 128),  # 自定义的中间层
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(128, num_classes)  # 输出层，与类别数匹配
        )

    def get_optimizer(self):
        # 设置优化器
        return torch.optim.AdamW([
            {'params': self.base.parameters(), 'lr': 3e-5},  # 主体模型的较小学习率
            {'params': self.base.head.parameters(), 'lr': 8e-4}  # 自定义层的较大学习率
        ])

    def forward(self, x):
        x = self.base(x)
        return x

# 假设有4个分类
num_classes = 4
model = SwinTransformerModel(num_classes=num_classes)

def set_seed(seed):
    random.seed(seed)                       # 设置Python的随机种子
    np.random.seed(seed)                    # 设置NumPy的随机种子
    torch.manual_seed(seed)                 # 设置PyTorch的CPU随机种子
    torch.cuda.manual_seed(seed)            # 设置当前GPU的随机种子（如果使用GPU）
    torch.cuda.manual_seed_all(seed)        # 设置所有GPU的随机种子（如果使用多个GPU）
    torch.backends.cudnn.deterministic = True  # 确保每次卷积操作结果一致
    torch.backends.cudnn.benchmark = False
from torch.utils.data import DataLoader, SubsetRandomSampler
import random
def l1_regularization(model, lambda_l1):
    l1_loss = 0.0
    for param in model.parameters():
        l1_loss += torch.sum(torch.abs(param))
    return lambda_l1 * l1_loss

# 训练新的模型
def generativeModel():
    global device, x_train, y_train

    # Set the seed for reproducibility
    
    batchsz =64
    lr = 1e-3
    epochs =21
    num_cuda_devices = torch.cuda.device_count()
    print(f"当前系统上有 {num_cuda_devices} 个可用的CUDA设备。")

    # 指定要使用的CUDA设备
    desired_device_id = 0  # 选择要使用的设备的ID
    if desired_device_id < num_cuda_devices:
        torch.cuda.set_device(desired_device_id)
        print(f"已将CUDA设备切换到设备ID为 {desired_device_id} 的设备。")
    else:
        print(f"指定的设备ID {desired_device_id} 超出可用的CUDA设备数量。")
    device = torch.device('cuda:0')
    parent_dir = os.path.dirname(os.getcwd())
    # 获取当前脚本文件的绝对路径
    script_path = os.path.abspath(__file__)
    # 获取当前脚本文件的父文件夹
    cwd_dir = os.path.dirname(script_path)

    

 
    model_name = ["mobilenet_v2_model","SwinTransformerModel","ConvNeXtModel"] 

    for index  in range(0,3):                    
        
        val_acc_Trial = np.zeros((5, epochs))
        train_acc_Trial = np.zeros((5, epochs))
        val_loss_Trial = np.zeros((5, epochs))
        train_loss_Trial = np.zeros((5, epochs))
        test_acc_list=np.zeros((5, 1))
        for ii in range(0, 5):  
            set_seed(42+index+ii )
             
            if model_name[index]=="mobilenet_v2_model":                
                model=Mobilenet_v2().to(device)             
            elif model_name[index]=="SwinTransformerModel":
                model=SwinTransformerModel().to(device)
            elif model_name[index]=="ConvNeXtModel":
                model=ConvNeXtModel().to(device)            
                model=AttentionResNetWithMHSA(num_classes=4).to(device)
            else:
                pass
            
            print(f"执行模型{model_name[index]}:第{ii}次 -------------")          
            
            filemame = f"images{0}.csv"

            

            if model_name[index] == "inception_model":                
                train_db = Pokemon(cwd_dir + '/data', filemame, 299, mode='train')
                val_db = Pokemon(cwd_dir + '/data', filemame, 299, mode='val')
                test_db = Pokemon(cwd_dir + '/data', filemame, 299, mode='test')
            else:
                train_db = Pokemon(cwd_dir + '/data', filemame, 224, mode='train')
                val_db = Pokemon(cwd_dir + '/data', filemame, 224, mode='val')
                test_db = Pokemon(cwd_dir + '/data', filemame, 224, mode='test')
                       

            # Create indices and random sampler
            indices = np.arange(len(train_db))
            indices1 = np.arange(len(val_db))
            indices2 = np.arange(len(test_db))
            # Use SubsetRandomSampler with a random seed
            sampler = SubsetRandomSampler(indices )
            sampler1 = SubsetRandomSampler(indices1)
            sampler2 = SubsetRandomSampler(indices2)           
            
            # 在DataLoader中设置generator参数
            train_loader = DataLoader(train_db, batch_size=batchsz, sampler=sampler)
            val_loader = DataLoader(val_db, batch_size=batchsz, shuffle=False)
            test_loader = DataLoader(test_db, batch_size=batchsz, shuffle=False)

            optimizer = optim.Adam(model.parameters(), lr=lr )
            criteon = nn.CrossEntropyLoss()

            best_acc, best_epoch = 0, 0
            global_step = 0
            
            for epoch in range(epochs):
                correct_train = 0  # 用于计算训练集上的准确率
                total_train = 0  # 训练样本总数
                train_loss = 0  # 用于计算训练集损失

                for step, (x, y) in enumerate(train_loader):
                    # x: [b, 3, 224, 224], y: [b]
                    x, y = x.to(device), y.to(device)

                    model.train()
                    logits = model(x,)

                    # 根据不同模型处理损失
                    if model_name[index] == 'inception_model':
                        loss = criteon(logits.logits, y)
                    else:
                        loss = criteon(logits, y)

                    regularization_loss = 0
                    for param in model.parameters():
                        regularization_loss += torch.norm(param).pow(2)
                    loss = loss + 0.01 * regularization_loss
                    optimizer.zero_grad()
                    loss.backward()
                    optimizer.step()

                    # 累加训练损失
                    train_loss += loss.item()

                    # 计算训练集准确率
                    if model_name[index] == 'inception_model':
                        _, preds = torch.max(logits.logits, 1)  # 获取每个样本的预测标签
                    else:
                        _, preds = torch.max(logits, 1)  # 获取每个样本的预测标签
                    correct_train += (preds == y).sum().item()
                    total_train += y.size(0)  # 累加样本数量

                    global_step += 1

                # 计算当前 epoch 的训练集平均损失和准确率
                train_acc = correct_train / total_train
                avg_train_loss = train_loss / len(train_loader)

                # 验证阶段
                model.eval()
                val_loss = 0
                correct_val = 0
                total_val = 0

                with torch.no_grad():
                    for val_x, val_y in val_loader:
                        val_x, val_y = val_x.to(device), val_y.to(device)

                        logits = model(val_x)

                        loss = criteon(logits, val_y)

                        # 累加验证集损失
                        val_loss += loss.item()
                        # val_loss +=l1_regularization(model, 0.01)

                        # 计算验证集准确率
                        _, val_preds = torch.max(logits, 1)
                        correct_val += (val_preds == val_y).sum().item()
                        total_val += val_y.size(0)

                # 计算验证集的平均损失和准确率
                avg_val_loss = val_loss / len(val_loader)
                val_acc = correct_val / total_val

                # 存储准确率和损失
                val_acc_Trial[ii, epoch] = val_acc
                train_acc_Trial[ii, epoch] = train_acc
                val_loss_Trial[ii, epoch] = avg_val_loss
                train_loss_Trial[ii, epoch] = avg_train_loss

                if epoch % 1 == 0:

                    # val_acc = evalute(model, val_loader)
                    if val_acc > best_acc:
                        best_epoch = epoch
                        best_acc = val_acc
                        dirp = cwd_dir
                        if os.path.exists(os.path.join(dirp,model_name[index],str(epochs),"50dim")) == False:
                            os.makedirs(os.path.join(dirp,model_name[index],str(epochs),"50dim"))
                        torch.save(model.state_dict(), f'{dirp}/{model_name[index]}/{str(epochs)}/50dim/best{ii}.mdl')                    

from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.ensemble import RandomForestClassifier
from scipy.stats import cauchy
from copy import deepcopy
from sklearn.cluster import KMeans
  
PopSize = 20
DimSize = 3
LB = [-100] * DimSize
UB = [100] * DimSize
TrialRuns = 1
MaxFEs = 1000 * DimSize

Pop = np.zeros((PopSize, DimSize))
Velocity = np.zeros((PopSize, DimSize))
FitPop = np.zeros(PopSize)
curFEs = 0
FuncNum = 1

His = np.zeros((PopSize, DimSize))
FitHis = np.zeros(PopSize)
H = 5
phi1 = [0.15] * H
phi2 = [0.15] * H
phi3 = [0.15] * H
elms=[]

def Initialization(func):
    global Pop, Velocity, FitPop, His, FitHis, phi1, phi2, phi3, H
    Velocity = np.zeros((PopSize, DimSize))
    for i in range(PopSize):
        for j in range(DimSize):
            Pop[i][j] = LB[j] + (UB[j] - LB[j]) * np.random.rand()
        FitPop[i] ,t= func(Pop[i])
    His = deepcopy(Pop)
    FitHis = deepcopy(FitPop)
    phi1 = [0.15] * H
    phi2 = [0.15] * H
    phi3 = [0.15] * H


def Check(indi):
    global LB, UB
    for i in range(DimSize):
        range_width = UB[i] - LB[i]
        if indi[i] > UB[i]:
            n = int((indi[i] - UB[i]) / range_width)
            mirrorRange = (indi[i] - UB[i]) - (n * range_width)
            indi[i] = UB[i] - mirrorRange
        elif indi[i] < LB[i]:
            n = int((LB[i] - indi[i]) / range_width)
            mirrorRange = (LB[i] - indi[i]) - (n * range_width)
            indi[i] = LB[i] + mirrorRange
        else:
            pass
    return indi

def MSPCSO(func):
    global Pop, Velocity, FitPop, His, FitHis, curFEs, phi1, phi2, phi3
    sequence = list(range(PopSize))
    np.random.shuffle(sequence)
    Off = np.zeros((PopSize, DimSize))
    FitOff = np.zeros(PopSize)
    Xmean = np.mean(Pop, axis=0)
    S_phi1, S_phi2, S_phi3 = [], [], []
    delta_phi1, delta_phi2, delta_phi3 = [], [], []
    idx_phi1, idx_phi2, idx_phi3 = np.random.randint(0, H, 3)
    for i in range(int(PopSize / 2)):
        idx1 = sequence[2 * i]
        idx2 = sequence[2 * i + 1]
        if FitPop[idx1] < FitPop[idx2]:
            Off[idx1] = deepcopy(Pop[idx1])
            FitOff[idx1] = FitPop[idx1]

            Vec1 = np.random.rand(DimSize) * (Pop[np.argmin(FitPop)] - Pop[idx2])
            Vec2 = np.random.rand(DimSize) * (Xmean - Pop[idx2])
            Vec3 = np.random.rand(DimSize) * (His[idx2] - Pop[idx2])

            r = np.random.rand()
            if r < 1 / 3:
                Phi1 = np.clip(np.random.normal(phi1[idx_phi1], 0.1), 0.001, 0.5)
                Velocity[idx2] = np.random.rand(DimSize) * Velocity[idx2] + np.random.rand(DimSize) * (Pop[idx1] - Pop[idx2]) + Phi1 * Vec1
                Off[idx2] = Pop[idx2] + Velocity[idx2]
                Off[idx2] = Check(Off[idx2])
                FitOff[idx2],t = func(Off[idx2])
                curFEs += 1
                if FitOff[idx2] < FitHis[idx2]:  # Individual update
                    FitHis[idx2] = FitOff[idx2]
                    His[idx2] = deepcopy(Off[idx2])
                if FitOff[idx2] < FitPop[idx2]:  # Record success history
                    S_phi1.append(Phi1)
                    delta_phi1.append(FitPop[idx2] - FitOff[idx2])
            elif r < 2 / 3:
                Phi2 = np.clip(np.random.normal(phi2[idx_phi2], 0.1), 0.001, 0.5)
                Velocity[idx2] = np.random.rand(DimSize) * Velocity[idx2] + np.random.rand(DimSize) * (Pop[idx1] - Pop[idx2]) + Phi2 * Vec2
                Off[idx2] = Pop[idx2] + Velocity[idx2]
                Off[idx2] = Check(Off[idx2])
                FitOff[idx2],t = func(Off[idx2])
                curFEs += 1
                if FitOff[idx2] < FitHis[idx2]:  # Individual update
                    FitHis[idx2] = FitOff[idx2]
                    His[idx2] = deepcopy(Off[idx2])
                if FitOff[idx2] < FitPop[idx2]:  # Record success history
                    S_phi2.append(Phi2)
                    delta_phi2.append(FitPop[idx2] - FitOff[idx2])
            else:
                Phi3 = np.clip(np.random.normal(phi3[idx_phi3], 0.1), 0.001, 0.5)
                Velocity[idx2] = np.random.rand(DimSize) * Velocity[idx2] + np.random.rand(DimSize) * (Pop[idx1] - Pop[idx2]) + Phi3 * Vec3
                Off[idx2] = Pop[idx2] + Velocity[idx2]
                Off[idx2] = Check(Off[idx2])
                FitOff[idx2],t = func(Off[idx2])
                curFEs += 1
                if FitOff[idx2] < FitHis[idx2]:  # Individual update
                    FitHis[idx2] = FitOff[idx2]
                    His[idx2] = deepcopy(Off[idx2])
                if FitOff[idx2] < FitPop[idx2]:  # Record success history
                    S_phi3.append(Phi3)
                    delta_phi3.append(FitPop[idx2] - FitOff[idx2])


        else:
            Off[idx2] = deepcopy(Pop[idx2])
            FitOff[idx2] = FitPop[idx2]

            Vec1 = np.random.rand(DimSize) * (His[idx1] - Pop[idx1])
            Vec2 = np.random.rand(DimSize) * (Pop[np.argmin(FitPop)] - Pop[idx1])
            Vec3 = np.random.rand(DimSize) * (Xmean - Pop[idx1])

            r = np.random.rand()
            if r < 1 / 3:
                Phi1 = np.clip(np.random.normal(phi1[idx_phi1], 0.1), 0.001, 0.5)
                Velocity[idx1] = np.random.rand(DimSize) * Velocity[idx1] + np.random.rand(DimSize) * (Pop[idx2] - Pop[idx1]) + Phi1 * Vec1
                Off[idx1] = Pop[idx1] + Velocity[idx1]
                Off[idx1] = Check(Off[idx1])
                FitOff[idx1],t = func(Off[idx1])
                curFEs += 1
                if FitOff[idx1] < FitHis[idx1]:
                    FitHis[idx1] = FitOff[idx1]
                    His[idx1] = deepcopy(Off[idx1])
                if FitOff[idx1] < FitPop[idx1]:
                    S_phi1.append(Phi1)
                    delta_phi1.append(FitPop[idx1] - FitOff[idx1])
            elif r < 2 / 3:
                Phi2 = np.clip(np.random.normal(phi2[idx_phi2], 0.1), 0.001, 0.5)
                Velocity[idx1] = np.random.rand(DimSize) * Velocity[idx1] + np.random.rand(DimSize) * (Pop[idx2] - Pop[idx1]) + Phi2 * Vec2
                Off[idx1] = Pop[idx1] + Velocity[idx1]
                Off[idx1] = Check(Off[idx1])
                FitOff[idx1],t = func(Off[idx1])
                curFEs += 1
                if FitOff[idx1] < FitHis[idx1]:
                    FitHis[idx1] = FitOff[idx1]
                    His[idx1] = deepcopy(Off[idx1])
                if FitOff[idx1] < FitPop[idx1]:
                    S_phi2.append(Phi2)
                    delta_phi2.append(FitPop[idx1] - FitOff[idx1])
            else:
                Phi3 = np.clip(np.random.normal(phi3[idx_phi3], 0.1), 0.001, 0.5)
                Velocity[idx1] = np.random.rand(DimSize) * Velocity[idx1] + np.random.rand(DimSize) * (Pop[idx2] - Pop[idx1]) + Phi3 * Vec3
                Off[idx1] = Pop[idx1] + Velocity[idx1]
                Off[idx1] = Check(Off[idx1])
                FitOff[idx1] ,t= func(Off[idx1])
                curFEs += 1
                if FitOff[idx1] < FitHis[idx1]:
                    FitHis[idx1] = FitOff[idx1]
                    His[idx1] = deepcopy(Off[idx1])
                if FitOff[idx1] < FitPop[idx1]:
                    S_phi3.append(Phi3)
                    delta_phi3.append(FitPop[idx1] - FitOff[idx1])

    c = 0.1
    if len(S_phi1) == 0:
        pass
    else:
        phi1[idx_phi1] = (1 - c) * phi1[idx_phi1] + c * meanWA(delta_phi1, S_phi1)
    if len(S_phi2) == 0:
        pass
    else:
        phi2[idx_phi2] = (1 - c) * phi2[idx_phi2] + c * meanWA(delta_phi2, S_phi2)
    if len(S_phi3) == 0:
        pass
    else:
        phi3[idx_phi3] = (1 - c) * phi3[idx_phi3] + c * meanWA(delta_phi3, S_phi3)

    Pop = deepcopy(Off)
    FitPop = deepcopy(FitOff)


def meanWA(delta, S):
    Delta = sum(delta)
    res = 0
    for i in range(len(S)):
        res += (delta[i] / Delta) * S[i]
    return res 
    
parent_dir = os.path.dirname(os.getcwd())
# 获取当前脚本文件的绝对路径
script_path = os.path.abspath(__file__)
# 获取当前脚本文件的父文件夹
cwd_dir = os.path.dirname(script_path)
device = torch.device('cuda:0')

model1=SwinTransformerModel().to(device)
model2= Mobilenet_v2().to(device)
model3=ConvNeXtModel().to(device)
epochs=21

val_loader=[]
p1= np.array([])
p2=np.array([])
p3=np.array([])
def main():
    import numpy as np
    global x_train, y_train, x_val, y_val, device,elms,model1,model2,model3,val_loader
    lr = 1e-3
    batchsz = 64

    parent_dir = os.path.dirname(os.getcwd())
    # 获取当前脚本文件的绝对路径
    script_path = os.path.abspath(__file__)
    # 获取当前脚本文件的父文件夹
    cwd_dir = os.path.dirname(script_path)
    

    model_name = ["mobilenet_v2_model", "SwinTransformerModel","ConvNeXtModel"]    
    for index  in range(len(model_name)): 
        
        All_Trial_Best = []
        elm_acc = []
        model_acc=[]
        val_model_acc=[]

        All_test_lable = []
        All_val_lable = []

        All_model_test_lable = []
        All_model_val_lable = []
        tag=0
        for ii in range(0, 5):
            val_loader=[]
            p1= np.array([])
            p2=np.array([])
            p3=np.array([])                        
             
            set_seed(42+index+ii )            
            if model_name[index]=="mobilenet_v2_model":                
                model=Mobilenet_v2().to(device)
            elif model_name[index]=="SwinTransformerModel":
                model=SwinTransformerModel().to(device)
            elif model_name[index]=="ConvNeXtModel":
                model=ConvNeXtModel().to(device)            
            else:
                pass

            print(f"执行模型{model_name[index]}:第{ii}次 -------------")
            
            filemame = f"images{0}.csv"           

            if model_name[index] == "inception_model":                
                train_db = Pokemon(cwd_dir + '/data', filemame, 299, mode='train')
                val_db = Pokemon(cwd_dir + '/data', filemame, 299, mode='val')
                test_db = Pokemon(cwd_dir + '/data', filemame, 299, mode='test')
            else:
                train_db = Pokemon(cwd_dir + '/data', filemame, 224, mode='train')
                val_db = Pokemon(cwd_dir + '/data', filemame, 224, mode='val')
                test_db = Pokemon(cwd_dir + '/data', filemame, 224, mode='test')
        

            
            indices = np.arange(len(train_db))
            indices1 = np.arange(len(val_db))
            indices2 = np.arange(len(test_db))            
            sampler = SubsetRandomSampler(indices)          


            # 在DataLoader中设置generator参数
            train_loader = DataLoader(train_db, batch_size=batchsz,  sampler=sampler)
            val_loader = DataLoader(val_db, batch_size=batchsz, shuffle=False)
            test_loader = DataLoader(test_db, batch_size=batchsz, shuffle=False)
             
            # 加载已经训练好的模型的值
            model.load_state_dict(torch.load(f'{cwd_dir}/{model_name[index]}/{str(epochs)}/50dim/best{ii}.mdl'))
            
            model1.load_state_dict(torch.load(f'{cwd_dir}/SwinTransformerModel/{str(epochs)}/50dim/best{ii}.mdl'))
            model2.load_state_dict(torch.load(f'{cwd_dir}/mobilenet_v2_model/{str(epochs)}/50dim/best{ii}.mdl'))
            model3.load_state_dict(torch.load(f'{cwd_dir}/ConvNeXtModel/{str(epochs)}/50dim/best{ii}.mdl'))

            # 存储生成的特征的路径，下次get_features就直接读取现成的特征文件
            file_path = os.path.join(cwd_dir, f'data/x_train{ii}_{model_name[index]}_50dim.pkl')
            file_path1 = os.path.join(cwd_dir, f'data/y_train{ii}_{model_name[index]}_50dim.pkl')
            file_path2 = os.path.join(cwd_dir, f'data/x_val{ii}_{model_name[index]}_50dim.pkl')
            file_path3 = os.path.join(cwd_dir, f'data/y_val{ii}_{model_name[index]}_50dim.pkl')
            file_path4 = os.path.join(cwd_dir, f'data/test{ii}_{model_name[index]}_50dim.pkl')
            file_path5 = os.path.join(cwd_dir, f'data/test_y{ii}_{model_name[index]}_50dim.pkl')


            # 获取训练，验证数据和测试数据
            train, train_y = get_features(model, train_loader, file_path, file_path1,model_name[index])
            val, val_y = get_features(model, val_loader, file_path2, file_path3,model_name[index])
            test, test_y = get_features(model, test_loader, file_path4, file_path5,model_name[index])

            
            x_train = train
            y_train = train_y
            x_val, y_val = val, val_y
            test, test_y = test, test_y
            
            from keras.utils import to_categorical
            y_train = to_categorical(y_train, 4)
            y_test = to_categorical(test_y, 4)
            y_val = to_categorical(val_y, 4)

            # Calculate total dimensions: weights + biases
            dimensions = 3            
            lb = np.ones(dimensions)*0
            ub = np.ones(dimensions)*1
            
            global curFEs, curFEs, TrialRuns, Pop, FitPop, DimSize,LB,UB,elms
            DimSize = dimensions
            LB =lb
            UB =ub
            import sys

            # 确保输出到标准输出而不是关闭的文件
            sys.stdout = sys.__stdout__
            
            All_Trial_Best = []
            MAX = 0
            for i in range(TrialRuns):
                BestList = []
                curFEs = 0
                np.random.seed(2000 + 22 * i)
                Initialization(softvote)
                BestList.append(min(FitPop))
                while curFEs < MaxFEs:
                    MSPCSO(softvote)
                    BestList.append(min(FitPop))

                    min_index=np.argmin(FitPop)

                    _,elms=softvote(Pop[min_index])
                All_Trial_Best.append(BestList)
            
            
            val_acc,val_y_pred =getvote(elms,val_loader,model1,model2,model3,y_val)            
            acc ,y_pred  =getvote(elms,test_loader,model1,model2,model3,y_test)           
            elm_acc.append( acc)

            All_test_lable.append(y_pred)
            All_val_lable.append(val_y_pred)
 
            print(f"inter:test_acc={ acc}")                 
            print(f"inter:val_acc={val_acc}")
            a,elms=softvote(Pop[min_index])
            print(f"inter:val_acc={a}")            
            
            if model_name[index]=="mobilenet_v2_model":                
                model0=Mobilenet_v2().to(device)          
                  
            elif model_name[index]=="SwinTransformerModel":
                model0=SwinTransformerModel().to(device)
            elif model_name[index]=="ConvNeXtModel":
                model0=ConvNeXtModel().to(device)            
            else:
                pass
            
            model0.load_state_dict(torch.load(f'{cwd_dir}/{model_name[index]}/{str(epochs)}/50dim/best{ii}.mdl'))
            val_acc,val_pred_y0 = get_evaluate_acc_pred0(model0, val_loader)
            val_model_acc.append(val_acc)
            test_acc ,test_pred_y0= get_evaluate_acc_pred0(model0, test_loader)
            model_acc.append(test_acc)
            All_model_test_lable.append(test_pred_y0)
            All_model_val_lable.append(val_pred_y0)   
            
        
        print(f"test_{model_name[index]}:平均精度：", np.mean(elm_acc))
        print(f"test_{model_name[index]}:平均精度：", np.mean(model_acc)) 
                
        print(f"val_{model_name[index]}:平均精度：", np.mean(val_model_acc))






def getvote(X,loader,model1,model2,model3,y_val):


   
    p1 = get_evaluate_acc_pred(model1,loader)
    p2 = get_evaluate_acc_pred(model2, loader)
    p3 = get_evaluate_acc_pred(model3, loader)


    pred_prob1 = torch.tensor(p1, dtype=torch.float32)
    pred_prob2 = torch.tensor(p2, dtype=torch.float32)
    pred_prob3 = torch.tensor(p3, dtype=torch.float32)  
    # pred_prob1 = model1.predict(X)  # 模型1的预测概率
    # pred_prob2 = model2.predict(X)  # 模型2的预测概率
    # pred_prob3 = model3.predict(X)  # 模型3的预测概率

    # 设置权重
    weights = [X[0], X[1], X[2]]  # 权重分别为2, 1, 3

    # 计算加权平均预测概率
    weighted_prob = (
        weights[0] * pred_prob1 +
        weights[1] * pred_prob2 +
        weights[2] * pred_prob3
    ) / sum(weights)

    # acc,_= get_evaluate_acc_pred0(model1, val_loader)
    # 最终预测类别（取概率最大的类别）
    y_pred = np.argmax(weighted_prob, axis=1)
    y = np.argmax(y_val,axis=1)
    accuracy = accuracy_score(y, y_pred)
    # print(accuracy)
    return accuracy,y_pred

def softvote(X):

    global x_train, y_train, x_val, y_val, TZnum, concatenate_x_train, concatenate_y_train, tag, test, test_y,model1,model2,model3,val_loader,p1,p2,p3
    
    if len(p1) == 0:
        p1 = get_evaluate_acc_pred(model1, val_loader)
        p2 = get_evaluate_acc_pred(model2, val_loader)
        p3 = get_evaluate_acc_pred(model3, val_loader)


    pred_prob1 = torch.tensor(p1, dtype=torch.float32)
    pred_prob2 = torch.tensor(p2, dtype=torch.float32)
    pred_prob3 = torch.tensor(p3, dtype=torch.float32)  
    # pred_prob1 = model1.predict(X)  # 模型1的预测概率
    # pred_prob2 = model2.predict(X)  # 模型2的预测概率
    # pred_prob3 = model3.predict(X)  # 模型3的预测概率

    # 设置权重
    weights = [X[0], X[1], X[2]]  # 权重分别为2, 1, 3

    # 计算加权平均预测概率
    weighted_prob = (
        weights[0] * pred_prob1 +
        weights[1] * pred_prob2 +
        weights[2] * pred_prob3
    ) / sum(weights)

    # acc,_= get_evaluate_acc_pred0(model1, val_loader)
    # 最终预测类别（取概率最大的类别）
    y_pred = np.argmax(weighted_prob, axis=1)
    y =np.argmax(y_val, axis=1)
    accuracy = accuracy_score(y, y_pred)
    # print(accuracy)
    return -1*accuracy,X

def get_features(model, train_loader, x_path, y_path,modelname):
    global device
    if (not os.path.exists(x_path)) or (not os.path.exists(y_path)):
        
        if modelname == 'inception_model':
            
            model.base.fc[4]=nn.Identity()
            model0 =model
        elif modelname == 'vgg16_model':
            model.classifier[-1]=nn.Identity()
            model0 =model

        elif modelname =='alexnet_model':
           model.base_model.classifier[-1]=nn.Identity()
           model0 =model
        elif modelname =='SwinTransformerModel':
           model.base.head[-1] =nn.Identity()
           model0 =model
        elif modelname =='ConvNeXtModel':
            model.base.classifier[2][-1]=nn.Identity()
            model0 =model
        else:

           model.block[3]=nn.Identity()
           model0 = model
        model0=model
        model0.eval()

        for step, (x, y) in enumerate(train_loader):
            x, y = x.to(device), y.to(device)
            with torch.no_grad():
                
            # 计算训练集准确率
                if modelname == 'inception_model':
                    logits = model0(x)
                    features = logits  # 获取每个样本的预测标签
                else:
                    logits = model0(x)
                    features =logits  # 获取每个样本的预测标签
                
                if step == 0:
                    result = features
                    result_y = y;
                else:
                    result = torch.cat([result, features], dim=0)
                    result_y = torch.cat([result_y, y], dim=0)
        result, result_y = result.cpu(), result_y.cpu()
        with open(x_path, 'wb') as file:
            pickle.dump(result, file)
        with open(y_path, 'wb') as file:
            pickle.dump(result_y, file)

        return result.numpy(), result_y.numpy()
    else:
        with open(x_path, 'rb') as file:
            result = pickle.load(file)
        with open(y_path, 'rb') as file:
            result_y = pickle.load(file)

        return result.numpy(), result_y.numpy()

 
 
 

if __name__ == '__main__':
    # generativeModel()
    main()
